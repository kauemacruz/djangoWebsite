from django.db import models

# Create your models here.
class Parent(models.Model):
	"""
	Parent Model
	Defines the attributes of a parent
	"""
	preferred_Title = models.CharField(max_length=3, null=True)
	fullName =  models.CharField(max_length=255, null=True)
	telephone_Mobile = models.IntegerField(null=True)
	telephone_Work = models.IntegerField(null=True)
	email = models.CharField(max_length=255, null=True)
	
	def get_parent(self):
		return self.preferred_Title + fullName

class Address(models.Model):
	"""
	Address Model
	Defines the attributes of an address
	"""
	street = models.CharField(max_length=255, null=True)
	suburb = models.CharField(max_length=255, null=True)
	postol_Code = models.IntegerField(null=True)

	def get_address(self):
		return street + suburb + postol_Code

class School(models.Model):
	"""
	School Model
	Defines the attributes of a Mainstream School
	"""
	name_Of_Mainstream_School = models.CharField(max_length=255, null=True)
	class_At_Mainstream_School = models.CharField(max_length=255, null=True)
	address = models.ForeignKey(Address, on_delete=models.CASCADE, related_name="address", null=True)

	def get_school(self):
		return self.name_Of_Mainstream_School + address

class Student(models.Model):
	"""
	Student Model
	Defines the attributes of a student
	"""
	parent = models.ForeignKey(Parent, on_delete=models.CASCADE, related_name="studentDetails", null=True)
	fullName_English = models.CharField(max_length=255, null=True)
	fullName_Tamil = models.CharField(max_length=255, null=True)
	date_Of_Birth = models.DateField(null=True)
	sex = models.CharField(max_length=255, null=True)
	residential_Status = models.CharField(max_length=255, null=True)
	previous_Attendance = models.BooleanField(null=True)
	school = models.ForeignKey(School, on_delete=models.CASCADE, null=True)
	user_ID = models.CharField(max_length=3, null=True)
	payment_Confirmed = models.BooleanField()

	def get_student(self):
		return self.fullName_English + date_of_birth + sex + school

class Doctor(models.Model):
	"""
	Doctor Model
	Defines the attributes of a doctor
	"""
	student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name="medicalDetails", null=True)
	fullName_English = models.CharField(max_length=255, null=True)
	fullName_Tamil = models.CharField(max_length=255, null=True)
	street_Name = models.CharField(max_length=255, null=True)
	suburb = models.CharField(max_length=255, null=True)
	postcode = models.IntegerField(null=True)
	telephone = models.IntegerField(null=True)
	medical_Conditions = models.CharField(max_length=255, null=True)
	routine_Medications = models.CharField(max_length=255, null=True)
	restriction_Sports = models.CharField(max_length=255, null=True)
	
	def get_doctor(self):
		return self.fullName_English + telephone + postcode + suburb

class Enrollment(models.Model):
	"""
	Enrollment Model
	Defines the attributes of a enrollment
	"""
	student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name="enrollentDetails", null=True)
	classStr = models.CharField(max_length=255, null=True)
	status= models.BooleanField(null=True)
	user_ID = models.CharField(max_length=3, null=True)

	def get_enrollment(self):
		return self.classStr + status 
class Status(models.Model):
	"""
	Status Model
	Defines the attributes of a status
	"""
	status= models.BooleanField(null= True)
	
	def get_status(self):
		return self.status 

class Search(models.Model):
	"""
	Search Model
	Defines the attributes of a search 
	"""
	student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name="SearchStudent", null=True)
	fullName_English = models.CharField(max_length=255, null=False)

	def get_doctor(self):
		return self.fullName_English
class Search_Parent(models.Model):
	"""
	Search_Parent
	Defines the attributes of a Search_Parent
	"""
	parent = models.ForeignKey(Parent, on_delete=models.CASCADE, related_name="SearchParent", null=True)
	fullName = models.CharField(max_length=255, null=True)

	def get_doctor(self):
		return self.fullName_English

class Search_Doctor(models.Model):
	"""
	Search_Doctor Model
	Defines the attributes of a search_Doctor
	"""
	student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name="SearchParent", null=True)
	fullName = models.CharField(max_length=255, null= True)
	fullName_Tamil = models.CharField(max_length=255, null=True)
	telephone = models.IntegerField(null=True)
	def get_doctor(self):
		return self.fullName_English

class Search_School(models.Model):
	"""
	Search_School Model
	Defines the attributes of a search_school
	"""
	name_Of_Mainstream_School = models.CharField(max_length=255, null=True)
	class_At_Mainstream_School = models.CharField(max_length=255, null=True)
	
	def get_school(self):
		return self.fullName_English

class Search_Address(models.Model):
	"""
	Search_Address Model
	Defines the attributes of a search_address
	"""
	street = models.CharField(max_length=255, null=True)
	suburb = models.CharField(max_length=255, null=True)
	postol_Code = models.IntegerField(null=True)

	def get_address(self):
		return self.fullName_English

class Search_Enrollment(models.Model):
	"""
	Student_Enrollment
	Defines the attributes  of a enrollment
	"""
	student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name="enrollmentDetails", null=True)
	classStr = models.CharField(max_length=255, null=True)
	status= models.BooleanField(null=True)
	
	def get_enrollment(self):
		return self.classStr + student + status

class Search_status(models.Model):
	"""
	Search_status Model
	Defines the attributes of a status
	"""
	status= models.BooleanField(null= True)

	def get_status(self):
		return self.status

class Search_Payment(models.Model):
	"""
	Search_Payment Model
	Defines the attributes of a student
	"""
	payment_Confirmed = models.BooleanField(null=False)

	def get_payment(self):
		return self.payment
