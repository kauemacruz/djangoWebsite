from django.conf.urls import url
from . import views


urlpatterns = [
    url(
        r'^api/v1/tamilschoolapi/(?P<pk>[0-9]+)$',
        views.get_delete_update_student,
        name='get_delete_update_student'
    ),

     url(
        r'^api/v1/tamilschoolapi/enrollments/(?P<pk>[0-9]+)$',
        views.get_delete_update_enrollment,
        name='get_delete_update_enrollment'
    ),
    url(
        r'^api/v1/tamilschoolapi/$',
        views.get_post_students,
        name='get_post_students'
    ),
    url(
        r'^api/v1/tamilschoolapi/parents/$',
        views.get_post_parents,
        name='get_post_parents'
    ),

     url(
        r'^api/v1/tamilschoolapi/doctors/$',
        views.get_post_doctors,
        name='get_post_doctors'
    ),

     url(
        r'^api/v1/tamilschoolapi/schools/$',
        views.get_post_schools,
        name='get_post_schools'
    ),

     url(
        r'^api/v1/tamilschoolapi/addresses/$',
        views.get_post_addresses,
         name='get_post_address'
    ),
     
       url(
        r'^api/v1/tamilschoolapi/enrollments/$',
        views.get_post_enrollments,
         name='get_post_enrollments'
    ),
            url(
        r'^api/v1/tamilschoolapi/statuses/$',
        views.get_post_statuses,
         name='get_post_statuses'
    ),
    url(r'^api/v1/tamilschoolapi/students/search/$', views.SearchAPIView.as_view()),
    url(r'^api/v1/tamilschoolapi/parents/search/$', views.SearchAPIParent.as_view()),
    url(r'^api/v1/tamilschoolapi/addresses/search/$', views.SearchAPIDoctor.as_view()),
    url(r'^api/v1/tamilschoolapi/schools/search/$', views.SearchAPISchool.as_view()),
    url(r'^api/v1/tamilschoolapi/enrollments/search/$', views.SearchAPIEnrollment.as_view()),
    url(r'^api/v1/tamilschoolapi/statuses/search/$', views.SearchAPIStatus.as_view()),
    url(r'^api/v1/tamilschoolapi/students/user/search/$', views.SearchAPIUser.as_view()),
    url(r'^api/v1/tamilschoolapi/enrollments/user/search/$', views.SearchAPIEnrollUser.as_view()),
    url(r'^api/v1/tamilschoolapi/students/paymentStatus/search/$', views.SearchAPIPayments.as_view())
]