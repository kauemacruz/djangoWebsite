from django.apps import AppConfig


class brisbanetamilschoolConfig(AppConfig):
    name = 'tamilschoolapi'
