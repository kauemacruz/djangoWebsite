from rest_framework import serializers
from .models import Parent, Student, Doctor, Address , School, Enrollment, Status


class ParentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Parent
        fields = ('preferred_Title', 'fullName', 'telephone_Mobile', 'telephone_Work', 'email')
        
class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = ('pk', 'parent', 'fullName_English', 'fullName_Tamil', 'date_Of_Birth', 'sex', 'residential_Status', 'previous_Attendance', 'school', 'user_ID', 'payment_Confirmed')

class DoctorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Doctor
        fields = ('student', 'fullName_English', 'fullName_Tamil', 'street_Name', 'suburb', 'postcode', 'telephone', 'medical_Conditions', 'routine_Medications','restriction_Sports')

class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = ('suburb' ,'street', 'postol_Code')

class SchoolSerializer(serializers.ModelSerializer):
    class Meta:
        model = School
        fields = ('name_Of_Mainstream_School' ,'class_At_Mainstream_School')

class EnrollmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Enrollment
        fields = ('pk', 'student', 'classStr', 'status', 'user_ID')