from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .serializers import ParentSerializer, StudentSerializer, DoctorSerializer, SchoolSerializer, AddressSerializer, EnrollmentSerializer
from .models import Parent, Student, Doctor, School, Address, Enrollment, Status
from rest_framework import generics
from rest_framework import filters
from datetime import datetime

# Create your views here.

@api_view(['GET', 'POST'])
def get_post_students(request):
    # get all students
    if request.method == 'GET':
        students = Student.objects.all()
        serializer = StudentSerializer(students, many=True)
        return Response(serializer.data)
    # insert a new record for a student
    if request.method == 'POST':
        data = {
            'parent': request.data.get('parent'),
            'date_Of_Birth': request.data.get('date_Of_Birth'),
            'fullName_English': request.data.get('fullName_English'),
            'fullName_Tamil': request.data.get('fullName_Tamil'),
			'sex': request.data.get('sex'),
			'residential_Status': request.data.get('residential_Status'),
			'previous_Attendance': bool(request.data.get('previous_Attendance')),
			'school': request.data.get('school'),
            'user_ID': request.data.get('user_ID'),
            'payment_Confirmed': request.data.get('payment_Confirmed')
        }
        serializer = StudentSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET', 'DELETE', 'PUT'])
def get_delete_update_student(request, pk):
    try:
        student = Student.objects.get(pk=pk)
    except Student.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)

    # get details of a single student
    if request.method == 'GET':
        serializer = StudentSerializer(student)
        return Response(serializer.data)

    # update details of a single student
    if request.method == 'PUT':
        serializer = StudentSerializer(student, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_204_NO_CONTENT)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    # delete a single student
    if request.method == 'DELETE':
        student.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(['GET', 'DELETE', 'PUT'])
def get_delete_update_enrollment(request, pk):
    try:
        enrollment = Enrollment.objects.get(pk=pk)
    except Enrollment.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)

    # get details of a single enrollment
    if request.method == 'GET':
        serializer = EnrollmentSerializer(enrollment)
        return Response(serializer.data)

    # update details of a single enrollment
    if request.method == 'PUT':
        serializer = EnrollmentSerializer(enrollment, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_204_NO_CONTENT)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    # delete a single enrollment
    if request.method == 'DELETE':
        enrollment.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(['GET', 'POST'])
def get_post_parents(request):
    # get all parents
    if request.method == 'GET':
        parents = Parent.objects.all()
        serializer = ParentSerializer(parents, many=True)
        return Response(serializer.data)
    # insert a new record for a parent
    if request.method == 'POST':
        data = {
            'preferred_Title': request.data.get('preferred_Title'),
            'fullName': request.data.get('fullName'),
			'telephone_Mobile': int(request.data.get('telephone_Mobile')),
			'telephone_Work': int(request.data.get('telephone_Work')),
			'email': request.data.get('email')
        }
        serializer = ParentSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
@api_view(['GET', 'POST'])
def get_post_doctors(request):
    # get all doctors
    if request.method == 'GET':
        doctors = Doctor.objects.all()
        serializer = DoctorSerializer(doctors, many=True)
        return Response(serializer.data)
    # insert a new record for a doctor
    if request.method == 'POST':
        data = {
             'student': request.data.get('student'),
            'fullName_English': request.data.get('fullName_English'),
            'fullName_Tamil': request.data.get('fullName_Tamil'),
			'street_Name': request.data.get('street_Name'),
			'suburb': request.data.get('suburb'),
			'postcode': request.data.get('postcode'),
			'telephone': request.data.get('telephone'),
            'medical_Conditions': request.data.get('medical_Conditions'),
            'routine_Medications': request.data.get('routine_Medications'),
            'restriction_Sports': request.data.get('restriction_Sports')
        }
        serializer = DoctorSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET', 'POST'])
def get_post_schools(request):
    # get all schools
    if request.method == 'GET':
        schools = School.objects.all()
        serializer = SchoolSerializer(schools, many=True)
        return Response(serializer.data)
    # insert a new record for a school
    if request.method == 'POST':
        data = {
            'name_Of_Mainstream_School': request.data.get('name_Of_Mainstream_School'),
            'class_At_Mainstream_School': request.data.get('class_At_Mainstream_School'),
			'address': request.data.get('address')
        }
        serializer = SchoolSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET', 'POST'])
def get_post_enrollments(request):
    # get all enrollments
    if request.method == 'GET':
        enrollments = Enrollment.objects.all()
        serializer = EnrollmentSerializer(enrollments, many=True)
        return Response(serializer.data)
    # insert a new record for a enrollment
    if request.method == 'POST':
        data = {
           
            'student': request.data.get('student'),
            'classStr': request.data.get('classStr'),
			'status':  bool(request.data.get('status')),
		    'user_ID': request.data.get('user_ID')
        }
        serializer = EnrollmentSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
@api_view(['GET', 'POST'])
def get_post_addresses(request):
    # get all addresses
    if request.method == 'GET':
        addresses = Address.objects.all()
        serializer = AddressSerializer(addresses, many=True)
        return Response(serializer.data)
    # insert a new record for a address
    if request.method == 'POST':
        data = {
            'student': request.data.get('student'),
            'street': request.data.get('street'),
            'suburb': request.data.get('suburb'),
			'postol_Code': int(request.data.get('postol_Code'))
        }
        serializer = AddressSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET', 'POST'])
def get_post_statuses(request):
    # get all statuses
    if request.method == 'GET':
        statuses = Status.objects.all()
        serializer = EnrollmentSerializer(statuses, many=True)
        return Response(serializer.data)
    # insert a new record for a enrollment status
    if request.method == 'POST':
        data = {
			'status':  bool(request.data.get('status'))
        }
        serializer = EnrollmentSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
class SearchAPIView(generics.ListCreateAPIView):
     search_fields = ['id', 'fullName_English']
     filter_backends = (filters.SearchFilter,)
     queryset = Student.objects.all()
     serializer_class = StudentSerializer

class SearchAPIParent(generics.ListCreateAPIView):
     search_fields = ['id', 'fullName', 'telephone_Mobile']
     filter_backends = (filters.SearchFilter,)
     queryset = Parent.objects.all()
     serializer_class = ParentSerializer

class SearchAPIDoctor(generics.ListCreateAPIView):
     search_fields = ['id', 'fullName_English','fullName_English','telephone']
     filter_backends = (filters.SearchFilter,)
     queryset = Doctor.objects.all()
     serializer_class = DoctorSerializer

class SearchAPIAddress(generics.ListCreateAPIView):
     search_fields = ['id','street' ,'suburb', 'postol_Code',]
     filter_backends = (filters.SearchFilter,)
     queryset = Address.objects.all()
     serializer_class = AddressSerializer

class SearchAPISchool(generics.ListCreateAPIView):
     search_fields = ['id','name_Of_Mainstream_School' ,'class_At_Mainstream_School']
     filter_backends = (filters.SearchFilter,)
     queryset = School.objects.all()
     serializer_class = SchoolSerializer

class SearchAPIEnrollment(generics.ListCreateAPIView):
     search_fields = ['id', 'classStr','status']
     filter_backends = (filters.SearchFilter,)
     queryset = Enrollment.objects.all()
     serializer_class = EnrollmentSerializer

class SearchAPIStatus(generics.ListCreateAPIView):
     search_fields = ['status']
     filter_backends = (filters.SearchFilter,)
     queryset = Enrollment.objects.all()
     serializer_class = EnrollmentSerializer

class SearchAPIPayments(generics.ListCreateAPIView):
     search_fields = ['payment_Confirmed']
     filter_backends = (filters.SearchFilter,)
     queryset = Student.objects.all()
     serializer_class = StudentSerializer

class SearchAPIUser(generics.ListCreateAPIView):
     search_fields = ['user_ID']
     filter_backends = (filters.SearchFilter,)
     queryset = Student.objects.all()
     serializer_class = StudentSerializer
     
class SearchAPIEnrollUser(generics.ListCreateAPIView):
     search_fields = ['user_ID']
     filter_backends = (filters.SearchFilter,)
     queryset = Enrollment.objects.all()
     serializer_class = EnrollmentSerializer