#!F:\Tafe\Term 4\Monday\ICTPRG604\AT2\tamil_api\tamil_api\env\Scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
