"""
This file demonstrates writing tests using the unittest module. These will pass
when you run "manage.py test".
"""

import django
from django.test import Client, TestCase
from django.contrib.auth import get_user_model, authenticate, login
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from .models import *
from app.views import *
from django.urls import reverse, resolve
from django.http import HttpResponseRedirect
from django.test.utils import setup_test_environment

# TODO: Configure your database in settings.py and sync before running tests.

class ViewTest(TestCase):
    """Tests for the application views."""

    if django.VERSION[:2] >= (1, 7):
        # Django 1.7 requires an explicit setup() when running tests in PTVS
        @classmethod
        def setUpClass(cls):
            super(ViewTest, cls).setUpClass()
            django.setup()

    def setUp(self):
        #register user
        self.user = get_user_model().objects.create_user(username='UnitTest', password='12test12', email='unittest@example.com')
        self.user.save()
        #login user
        login = self.client.login(username='UnitTest', password='12test12')

    def test_users_count(self):
        users = User.objects.all()
        print(users.Count())
        self.assertEqual(users.count(), 1)

    def test_index_page(self):
        c = Client()
        response = c.get('/')
        print(response.status_code)
        self.assertEqual(response.status_code, 200)

    def test_register_page(self):
        c = Client()
        response = c.get('/register/')
        print(response.status_code)
        self.assertEqual(response.status_code, 200)

    def test_login_page(self):
        c = Client()
        response = c.get('/login/')
        print(response.status_code)
        self.assertEqual(response.status_code, 200)

    def test_correct(self):
        user = authenticate(username='UnitTest', password='12test12')
        self.assertTrue((user is not None) and user.is_authenticated)

    def test_wrong_pssword(self):
        user = authenticate(username='UnitTest', password='wrong')
        self.assertFalse(user is not None and user.is_authenticated)

    def tearDown(self):
        self.user.delete()