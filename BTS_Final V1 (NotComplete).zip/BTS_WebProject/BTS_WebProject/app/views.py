"""
Definition of views.
"""

from django.core.mail import send_mail
from datetime import datetime
from django.shortcuts import render, redirect
from django.http import HttpRequest, HttpResponseRedirect, HttpResponse
from django import forms
from django.urls import reverse
from django.contrib import messages
from .models import *
from django.contrib.auth.forms import UserCreationForm, PasswordChangeForm
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from .forms import CreateUserForm, StudentData, StudentUpdate
from django.contrib.auth.decorators import login_required, permission_required
from .decorators import unauthenticated_user, allowed_users, admin_only
from django.contrib.auth.models import Group
from collections import ChainMap

import json, requests, _datetime
from django.core.serializers.json import DjangoJSONEncoder

API_PORT = "58546"

@unauthenticated_user
def registerPage(request):
    form = CreateUserForm()

    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        if form.is_valid():
            user = form.save()

            group = Group.objects.get(name='customer')
            user.groups.add(group)

            return HttpResponseRedirect(reverse('login'))

    context = {'form':form, 'year':datetime.now().year, 'title':'Register'}
    return render(request, 'app/register.html', context)

@unauthenticated_user
def loginPage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            if not request.POST.get("chk"):
                request.session.set_expiry(86400)
            return HttpResponseRedirect(reverse('studentForm'))
        else:
            return render(request, 'app/login.html', {
                'error_message': ' Login Failed! Enter the username and password correctly', 'title':'Login', 'year':datetime.now().year})

    context = {'title':'Login', 'year':datetime.now().year}
    return render(request, 'app/login.html', context)

def logoutUser(request):
    logout(request)
    return redirect('login')

@login_required(login_url='login')
def studentForm(request):
    """Renders the Student Form page"""
    form = StudentData()
    if request.method == 'POST':
            form = StudentData(request.POST)
            if form.is_valid():
                form.save()
                if form.cleaned_data['boxCheck'] == True:
                    messages.info(request, 'You have checked the declaration box')
                    parentData01 = {'preferred_Title': request.POST.get('Parent_Title'),
                        'fullName': form.cleaned_data['parent1Name'],
                        'telephone_Mobile': int(form.cleaned_data['parent1Mobile']),
                        'telephone_Work': int(form.cleaned_data['parent1Workphone']),
                        'email': form.cleaned_data['parent1Email']}
                    response01_post = requests.post('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/parents/', json=parentData01)
                    response01 = requests.get('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/parents/')
                    parent01ID = len(response01.json())
                    if form.data['parent2Name']:
                        parentData02 = {'preferred_Title': request.POST.get('ParentB_Title'),
                            'fullName': form.cleaned_data['parent2Name'],
                            'telephone_Mobile': int(form.cleaned_data['parent2Mobile']),
                            'telephone_Work': int(form.cleaned_data['parent2Workphone']),
                            'email': form.cleaned_data['parent2Email']}
                        response02_post = requests.post('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/parents/', json=parentData02)
                        response02 = requests.get('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/parents/')
                        parent02ID = len(response02.json())
                
                    if form.data['schoolStreet']:
                        schoolAddressData = {'street': form.cleaned_data['schoolStreet'],
                            'suburb': form.cleaned_data['schoolSuburb'],
                            'postol_Code': int(form.cleaned_data['schoolPostCode'])}
                        response07_post = requests.post('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/addresses/', json=schoolAddressData)
                        response07 = requests.get('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/addresses/')
                        schoolAddress = len(response07.json())

                    studentAddressData = {'street': form.cleaned_data['residentialAddress'],
                        'suburb': form.cleaned_data['residentilaSuburb'],
                        'postol_Code': int(form.cleaned_data['residentialPostCode'])}
                    response04_post = requests.post('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/addresses/', json=studentAddressData)
                    response04 = requests.get('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/addresses/')
                    studentAddress = len(response04.json())

                    response10 = requests.get('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/schools/search/?search=' + form.cleaned_data['schoolName'])
                    schoolVer = len(response10.json())
                    if schoolVer == 0:
                        schoolData = {'name_Of_Mainstream_School': form.cleaned_data['schoolName'],
                        'class_At_Mainstream_School': form.cleaned_data['schoolClass'],
                        'address': studentAddress}
                        response06_post = requests.post('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/schools/', json=schoolData)
                    response06 = requests.get('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/schools/')
                    schoolID = len(response06.json())

                    DOB = form.cleaned_data['birthDate'].strftime('%Y-%m-%d')
                    studentData = {'parent': parent01ID,
                        'fullName_English': form.cleaned_data['fullName'],
                        'fullName_Tamil': form.cleaned_data['tamilName'],
                        'date_Of_Birth': DOB,
                        'sex': request.POST.get('Sex'),
                        'residential_Status': request.POST.get('Residential_Status'),
                        'previous_Attendance': request.POST.get('Prev_Attendance'),
                        'school': schoolID,
                        'user_ID': request.user.id,
                        'payment_Confirmed': False}
                    #print(studentData)
                    response03_post = requests.post('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/', json=studentData)
                    response03 = requests.get('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/')
                    studentID = len(response03.json())

                    doctorData = {'student': studentID,
                        'fullName_English': form.cleaned_data['doctor'],
                        'fullName_Tamil': form.cleaned_data['doctortamilName'],
                        'street_Name': form.cleaned_data['doctorAddress'],
                        'suburb': form.cleaned_data['doctorSuburb'],
                        'postcode': int(form.cleaned_data['doctorPostCode']),
                        'telephone': int(form.cleaned_data['doctorNumber']),
                        'medical_Conditions': request.POST.get('student_medical'),
                        'routine_Medications': request.POST.get('student_routine'),
                        'restriction_Sports': request.POST.get('student_restrictions')}
                    response05_post = requests.post('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/doctors/', json=doctorData)
                    response05 = requests.get('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/doctors/')
                    doctorID = len(response05.json())

                    enrollmentData = {'student': studentID,
                                        'classStr': 'Undetermined',
                                        'status': False,
                                        'user_ID': request.user.id}
                    response011_post = requests.post('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/enrollments/', json=enrollmentData)

                    group = Group.objects.get(name='parent')
                    user = request.user
                    user.groups.add(group)
                    group = Group.objects.get(name='customer')
                    user.groups.remove(group)

                    return render(request, "app/studentForm.html", {'title':'Student Form', 'year':datetime.now().year, "form": form})
                else:
                    messages.info(request, 'You have not checked the declaration box')
    return render(request, "app/studentForm.html", {'title':'Student Form', 'year':datetime.now().year, "form": form})

@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
@admin_only
def searchStudent(request):

    if request.method == 'POST':
        studentID = request.POST.get('studentID')
        response = requests.get('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/students/search/?search=' + studentID)
        students = response.json()
        return render(request, "app/searchStudent.html", {"students": students, 'year':datetime.now().year})
    #form = StudentData(request.GET)
    return render(request, "app/searchStudent.html", {'title':'Student Search', 'year':datetime.now().year})

@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
@admin_only
def enrollment(request):
    response = requests.get('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/statuses/search/?search=' + '0')
    enrollments = response.json()
    return render(request, 'app/enrollment.html', {'title':'Enrolment', 'year':datetime.now().year, "enrollments": enrollments})

@login_required(login_url='login')
def checkout(request):
    id = str(request.user.id)
    #response04 = requests.get('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/enrollments/user/search/?search=' + id)
    #enrollments01 = response04.json()
    response01 = requests.get('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/statuses/search/?search=' + '1')
    enrollments = response01.json()
    #response02 = requests.get('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/')
    response02 = requests.get('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/students/user/search/?search=' + id)
    students = response02.json()

    response03 = requests.get('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/students/paymentStatus/search/?search=' + '0')
    paidStudents = response03.json()

    if request.method == "POST":
        return render(request, 'app/checkout.html', {'title':'Check out', 'year':datetime.now().year})

    return render(request, 'app/checkout.html', {'title':'Check out', 'year':datetime.now().year, "enrollments": enrollments,
                                                 "students": students, "paidStudents": paidStudents})

def Home(request):
    """Renders the home page."""
    assert isinstance(request, HttpRequest)
    return render(request, 'app/index.html', {'title':'Home Page', 'year':datetime.now().year})

def contact(request):
    """Renders the contact page."""
    assert isinstance(request, HttpRequest)
    return render(
        request,
        'app/contact.html',
        {
            'title':'Contact',
            'message':'Your contact page.',
            'year':datetime.now().year,
        }
    )

def about(request):
    """Renders the about page."""
    assert isinstance(request, HttpRequest)
    return render(
        request,
        'app/about.html',
        {
            'title':'About',
            'message':'Your application description page.',
            'year':datetime.now().year,
        }
    )

@login_required(login_url='login')
def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            messages.success(request, 'Your password was successfully updated!')
            return redirect('change_password')
        else:
            messages.error(request, 'Please correct the error below.')
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'app/updatePass.html', {
        'form': form, 'year':datetime.now().year
    })

@login_required(login_url='login')
def orderconfirm(request, msg, studentIDS):
    x = studentIDS.split(" ")
    studentCount = len(x)
    print(x[0])
    #response = requests.get('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/students/search/?search=' + x[1])
    #students = response.json()
    
    studentData = {'payment_Confirmed': True}
    response01_post = requests.put('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/' + str(x[0]), json=studentData)

    send_mail(
    'Payment Confirmation',
    'Payment details are as follows: \n' + msg,
    'design@MajesticIT.com.au',
    [request.user.email],
    fail_silently=False,)

    return render(request, 'app/orderConfirm.html', {'title':'Order Confirmation Page',
            'message':'Order Confirmation Page for Project.',
            'year':datetime.now().year,
            'orderstatus':'Order Confirmed',
            'ordermessage': msg,})

@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
@admin_only
def acceptEnrollment(request, pk):
    if request.method == "POST":
        enrollmentData = {'classStr': request.POST.get('enrollment_Class'), 'status': True}
        response01_put = requests.put('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/enrollments/' + str(pk), json=enrollmentData)
        response01_get = requests.get('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/enrollments/search/?search=' + str(pk))
        enrollments = response01_get.json()
        myDict = dict(ChainMap(*enrollments ))
        userID = myDict['user_ID']
        studentID = myDict['student']
        response_02 = requests.get('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/students/search/?search=' + str(studentID))
        students = response_02.json()

        myDict02 = dict(ChainMap(*students ))
        studentEngName = myDict02['fullName_English']
        studentTamName = myDict02['fullName_Tamil']
        DOB = myDict02['date_Of_Birth']
        gender = myDict02['sex']
        residential_Status = myDict02['residential_Status']
        previous_Attendance = myDict02['previous_Attendance']
        paymentStatus = myDict02['payment_Confirmed']

        user  = User.objects.get(id = userID)
        user_email = user.email
        send_mail(
        'Enrollment Confirmation',
        'Dear ' + studentEngName + ' Parent, \n' + 'Brisbane Tamil School would like to inform you that your childs enrollment at the school has been ' +
        'confirmed for; \n' + 'Student Full English Name: ' + studentEngName + '\n'
        + 'Student Full Tamil Name: ' + studentTamName + '\n'
        + 'Student Date of Birth: ' + DOB + '\n'
        + 'Student Gender: ' + gender + '\n'
        + 'Student Residential Status: ' + str(residential_Status) + '\n'
        + 'Student Previous Attendance of Brisbane Tamil School: ' + str(previous_Attendance) + '\n'
        + 'Student Payment Confirmed: ' + str(paymentStatus) + '\n\n'
        + 'If you have any questions or if the information provided is incorrect in anyway, dont hesitate to contact us at design@MajesticIT.com.au \n\n'
        + 'From Brisbane Tamil School',
        'design@MajesticIT.com.au',
        [user_email],
        fail_silently=False,)
        return HttpResponseRedirect(reverse('enrollment'))

@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
@admin_only
def declineEnrollment(request, pk):
    response01_get = requests.get('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/enrollments/search/?search=' + str(pk))
    enrollments = response01_get.json()
    myDict = dict(ChainMap(*enrollments ))
    userID = myDict['user_ID']
    studentID = myDict['student']
    response_02 = requests.get('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/students/search/?search=' + str(studentID))
    students = response_02.json()
    user  = User.objects.get(id = userID)
    user_email = user.email
    myDict02 = dict(ChainMap(*students ))
    studentEngName = myDict02['fullName_English']
    studentTamName = myDict02['fullName_Tamil']
    DOB = myDict02['date_Of_Birth']
    gender = myDict02['sex']
    residential_Status = myDict02['residential_Status']
    previous_Attendance = myDict02['previous_Attendance']
    paymentStatus = myDict02['payment_Confirmed']

    send_mail(
    'Enrollment Declined',
    'The enrollment has been cancelled for; \n' + 'Student Full English Name: ' + studentEngName + '\n'
        + 'Student Full Tamil Name: ' + studentTamName + '\n'
        + 'Student Date of Birth: ' + DOB + '\n'
        + 'Student Gender: ' + gender + '\n'
        + 'Student Residential Status: ' + str(residential_Status) + '\n'
        + 'Student Previous Attendance of Brisbane Tamil School: ' + str(previous_Attendance) + '\n'
        + 'Student Payment Confirmed: ' + str(paymentStatus) + '\n\n'
        + 'If you have any questions or if the information provided is incorrect in anyway, dont hesitate to contact us at design@MajesticIT.com.au \n\n'
        + 'From Brisbane Tamil School',
    'design@MajesticIT.com.au',
    [user_email],
    fail_silently=False,)
    response = requests.delete('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/enrollments/' + str(pk))
    return HttpResponseRedirect(reverse('enrollment'))

@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
@admin_only
def registerAdm(request):
    form = CreateUserForm()

    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            
            if request.POST.get('Role') == "Admin":
                group = Group.objects.get(name='admin')
                user.groups.add(group)
                user.is_staff = True
            if request.POST.get('Role') == "Parent":
                group = Group.objects.get(name='parent')
                user.groups.add(group)
            if request.POST.get('Role') == "Customer":
                group = Group.objects.get(name='customer')
                user.groups.add(group)

            return HttpResponseRedirect(reverse('Home'))

    context = {'form':form, 'year':datetime.now().year, 'title':'Register Admin/ Parent/ New User'}
    return render(request, 'app/registerAdm.html', context)

@login_required(login_url='login')
@allowed_users(allowed_roles=['parent'])
def updateStudent(request):
    form = StudentUpdate()
    if request.method == 'POST':
        studentID = request.POST.get('studentID')
        id = str(request.user.id)
        response01 = requests.get('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/enrollments/user/search/?search=' + id)
        enrollments = response01.json()
        response = requests.get('http://127.0.0.1:' + API_PORT + '/api/v1/tamilschoolapi/students/search/?search=' + studentID)
        students = response.json()

        myDict = dict(ChainMap(*students ))
        fullName = myDict['fullName_English']
        tamilName = myDict['fullName_Tamil']
        DOB = myDict['date_Of_Birth']
        sex = myDict['sex']
        residentialStatus = myDict['residential_Status']
        prev_Attendance = myDict['previous_Attendance']
        form = StudentUpdate(instance=myDict[0])

        #residentialAddress
        #residentialSuburb
        #residentialPostCode

        return render(request, "app/updateStudent.html", {"students": students, 'year':datetime.now().year, "form": form})
    return render(request, "app/updateStudent.html", {'title':'Student Search', 'year':datetime.now().year, "form": form})
