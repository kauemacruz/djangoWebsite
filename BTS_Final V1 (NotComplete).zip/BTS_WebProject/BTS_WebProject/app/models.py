"""
Definition of models.
"""

from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Application(models.Model):
    fullName = models.CharField(max_length=255, null=False)
    tamilName = models.CharField(max_length=255, null=True, blank=True)
    birthDate = models.DateField(null=False)
    schoolName = models.CharField(max_length=255, null=True, blank=True)
    schoolClass = models.CharField(max_length=200, null=True, blank=True)
    schoolStreet = models.CharField(max_length=255, null=True, blank=True)
    schoolSuburb = models.CharField(max_length=255, null=True, blank=True)
    schoolPostCode = models.IntegerField(max_length=4, null=True, blank=True)
    residentialAddress = models.CharField(max_length=255, null=False)
    residentilaSuburb = models.CharField(max_length=255, null=False)
    residentialPostCode = models.IntegerField(max_length=4, null=False)
    parent1Name = models.CharField(max_length=255, null=False)
    parent1Mobile  = models.IntegerField(null=False)
    parent1Workphone = models.IntegerField(null=True, blank=True)
    parent1Email = models.CharField(max_length=255, null=True, blank=True)
    parent2Name = models.CharField(max_length=255, null=True, blank=True)
    parent2Mobile  = models.IntegerField(null=True, blank=True)
    parent2Workphone = models.IntegerField(null=True, blank=True)
    parent2Email = models.CharField(max_length=255, null=True, blank=True)
    doctor = models.CharField(max_length=255, null=True, blank=True)
    doctortamilName = models.CharField(max_length=255, null=True, blank=True)
    doctorAddress = models.CharField(max_length=255, null=True, blank=True)
    doctorSuburb = models.CharField(max_length=255, null=True, blank=True)
    doctorPostCode = models.IntegerField(max_length=4, null=True, blank=True)
    doctorNumber =  models.IntegerField(null=True, blank=True)
    boxCheck = models.BooleanField(default=False)