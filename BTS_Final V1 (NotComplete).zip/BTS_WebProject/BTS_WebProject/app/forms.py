"""
Definition of forms.
"""

from django import forms
from django.contrib.auth.forms import AuthenticationForm
from django.utils.translation import ugettext_lazy as _

class BootstrapAuthenticationForm(AuthenticationForm):
    """Authentication form which uses boostrap CSS."""
    username = forms.CharField(max_length=254,
                               widget=forms.TextInput({
                                   'class': 'form-control',
                                   'placeholder': 'User name'}))
    password = forms.CharField(label=_("Password"),
                               widget=forms.PasswordInput({
                                   'class': 'form-control',
                                   'placeholder':'Password'}))


from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django import forms
from django.db import models
from django.forms import ModelForm
from .models import Application

class CreateUserForm(UserCreationForm):
    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')

class studentID(models.Model):
    studentID = models.CharField(max_length=3)

    def __unicode__(self):
        return self.studentID

class DateInput(forms.DateInput):
    input_type = 'date'

class StudentData(ModelForm):
    class Meta:
        model = Application
        fields = ['fullName', 
                  'tamilName',
                  'birthDate',
                  'schoolName',
                  'schoolClass',
                  'schoolStreet',
                  'schoolSuburb',
                  'schoolPostCode', 
                  'residentialAddress', 
                  'residentilaSuburb',
                  'residentialPostCode',
                  'parent1Name',
                  'parent1Mobile',
                  'parent1Workphone',
                  'parent1Email',
                  'parent2Name',
                  'parent2Mobile',
                  'parent2Workphone',
                  'parent2Email',
                  'doctor',
                  'doctorAddress',
                  'doctortamilName',
                  'doctorSuburb', 
                  'doctorPostCode',
                  'doctorNumber',
                  'boxCheck']
        birthDate = forms.DateField(widget=DateInput)
        widgets = {'birthDate' : DateInput()}
        boxCheck = forms.BooleanField(
        error_messages={'required': 'You must confirm you have read all the information above'},
        label="I declare that I have read all information above")

class StudentUpdate(forms.Form):
    fullName = forms.CharField(label='English Full Name', widget=forms.TextInput(attrs={'placeholder': 'English Name'}), required=True)
    tamilName = forms.CharField(label='Tamil Full Name', widget=forms.TextInput(attrs={'placeholder': 'Tamil Name'}), required=False)
    residentialAddress = forms.CharField(label='Residential Adress', widget=forms.TextInput(attrs={'placeholder': '0000, Street Name'}), required=True)
    residentialSuburb = forms.CharField(label='Residential Suburb', widget=forms.TextInput(attrs={'placeholder': 'Suburb'}), required=True)
    residentialPostCode = forms.IntegerField(label='Residential PostCode', widget=forms.TextInput(attrs={'placeholder': '0000'}), required=True)

    Sex = (('1', 'Male'),('2', 'Female'))
    #sex = forms.ChoiceField(choices=CHOICES)
    sex = forms.ChoiceField(label='sex', widget=forms.Select, choices=Sex)

    ResidentialStatus = (('1', 'Tourist'),('2', 'Student'),('3', 'Resident'),('4', 'Citizen'))
    #residentialStatus = forms.ChoiceField(choices=CHOICES)
    residentialStatus = forms.ChoiceField(label='ResidentialStatus', widget=forms.Select, choices=ResidentialStatus)

    Prev_Attendance = (('1', 'Yes'),('2', 'No'))
    #prev_Attendance = forms.ChoiceField(choices=CHOICES)
    prev_Attendance = forms.ChoiceField(label='Prev_Attendance', widget=forms.Select, choices=Prev_Attendance)
