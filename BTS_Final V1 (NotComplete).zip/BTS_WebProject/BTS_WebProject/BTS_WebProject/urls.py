"""
Definition of urls for BTS_WebProject.
"""

from datetime import datetime
from django.urls import path, include
from django.conf.urls import url
from django.contrib import admin
from django.contrib.auth.views import LoginView, LogoutView
from django.contrib.auth import views as auth_views
from app import forms, views


urlpatterns = [
    path('', views.Home, name='Home'),
    path('contact/', views.contact, name='contact'),
    path('about/', views.about, name='about'),
    path('login/',
         LoginView.as_view
         (
             template_name='app/login.html',
             authentication_form=forms.BootstrapAuthenticationForm,
             extra_context=
             {
                 'title': 'Log in',
                 'year' : datetime.now().year,
             }
         ),
         name='login'),
    path('register/', views.registerPage, name='register'),
    path('registerAdm/', views.registerAdm, name='registerAdm'),
    path('searchStudent/', views.searchStudent, name='searchStudent'),
    path('studentForm/', views.studentForm, name='studentForm'),
    path('enrollment/', views.enrollment, name='enrollment'),
    path('checkout/', views.checkout, name='checkout'),

    path('updatePass/', views.change_password, name='change_password'),
    path('passReset/', auth_views.PasswordResetView.as_view(), name='reset_password'),
    path('passReset_Sent/', auth_views.PasswordResetDoneView.as_view(), name='password_reset_done'),
    path('passReset/<uidb64>/<token>/',
        auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('passReset_Complete', auth_views.PasswordResetCompleteView.as_view(), name='password_reset_complete'),
    path('logout/', LogoutView.as_view(next_page='/'), name='logout'),
    path('admin/', admin.site.urls),

    path('orderconfirm/<str:msg>/<str:studentIDS>', views.orderconfirm, name='orderconfirm'),

    path('acceptEnrollment/<int:pk>', views.acceptEnrollment, name='acceptEnrollment'),
    path('declineEnrollment/<int:pk>', views.declineEnrollment, name='declineEnrollment'),
    path('updateStudent/', views.updateStudent, name='updateStudent')
]
