#!D:\Tafe\Term 4\Monday\ICTPRG604\AT2\BTS_WebProject\BTS_WebProject\env\Scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
